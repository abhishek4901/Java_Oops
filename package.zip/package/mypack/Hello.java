// File: lib/mypack/Hello.java
package mypack;

public class Hello {
    public void sayHello() {
        System.out.println("Hello from mypack!");
    }
}
