import mypack.Hello;

public class MainApp {
    public static void main(String[] args) {
        Hello h = new Hello();
        h.sayHello();
    }
}
