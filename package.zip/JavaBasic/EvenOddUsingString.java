class EvenOddUsingString{
    public static void main(String[] args) {
        
        int n = 90;
        String [] result = {"Even","Odd"};
        System.out.println(result[n%2]);
    }
}